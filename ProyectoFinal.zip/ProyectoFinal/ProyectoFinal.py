#Paulina Mendoza Iglesias
#Programa que duvuelve al usuario el programa Adobe que debe de utilizar de acuerdo a las preguntas que responde

from PIL import Image


def cargarAudition (archivo): # Función que devuelve la imagen de Audition 
    img = Image.open(archivo)
    return img

def cargarPhotoshop (archivo): # Función que devuelve la imagen de Photoshop
    img = Image.open(archivo)
    return img

def cargarLight (archivo): # Función que devuelve la imagen de Light
    img = Image.open(archivo)
    return img

def cargarPremiere (archivo): # Función que devuelve la imagen de Premiere
    img = Image.open(archivo)
    return img

def cargarAfter (archivo): # Función que devuelve la imagen de After
    img = Image.open(archivo)
    return img



def main(): # Función que corre el programa 
    
    logo = ["After.png","Audition.png","Light.png","Photo.png","Premiere.png"] # Lista con las imágenes que devuelve el programa 

    print ("¿Cual es la función principal de tu proyecto?")
    print ("1. Audio \n2. Imagen")
    print ("3. Obtener información")
    print ("0. Salir")
    opcionUno = int(input("Teclea el número que indique tu opción: "))

    while opcionUno != 0:
        
        if opcionUno == 1:
            print(" ")
            print ("El programa recomendado es: Adobe Audition")
            imagen = cargarAudition(logo[1])
            imagen.show ()
            break
    
    
        elif opcionUno == 2:
            print (" ")
            print ("¿La imagen es relacionada al diseño gráfico o video?")
            print ("3. Diseño gráfico \n4. Video")
            opcionDos = int(input("Teclea el número que indique tu opción: "))
            
            
        elif opcionUno == 3:
             print(" ")
             print("Creadora del programa: Paulina Mendoza Iglesias")
             print("Matrícula: A01745969")
             print("Carrera: LCMD")
             print("Semestre: 5º")
             print("Acerca de: El programa se encarga de preguntarle al usuario algunas características de su proyecto\ncon base en sus respuestas el programa ofrece la mejor opción para que cada persona sepa qué programa de Adobe le conviene más.")
             exit(0)
        
        while opcionDos != 0:
            if opcionDos == 3:
                print (" ")
                print ("¿Buscas diseñar o corregir color?")
                print ("1. Diseñar \n2. Corregir color")
                opcionImagen = int(input("Teclea el número que indique tu opción: "))
                
                while opcionImagen != 0:
                    if opcionImagen == 1:
                        print(" ")
                        print("El programa recomendado es: Adobe Photoshop")
                        imagen = cargarPhotoshop (logo[3])
                        imagen.show ()
                        exit(0)
                        
                    elif opcionImagen == 2:
                        print(" ")
                        print("El programa recomendado es: Adobe Lightroom")
                        imagen = cargarLight (logo[2])
                        imagen.show ()
                        exit(0)
                        
                    elif opcionImagen == 0:
                        exit(0)
            
            elif opcionDos != 0:
                
                if opcionDos == 4:
                    print (" ")
                    print ("¿Buscas editar con efectos especiales?")
                    print ("1. Sí \n2. No")
                    opcionVideo = int(input("Teclea el número que indique tu opción: "))
                
                while opcionVideo != 0:
                    if opcionVideo == 1:
                        print(" ")
                        print("El programa recomendado es: Adobe After Effects")
                        imagen = cargarAfter (logo[0])
                        imagen.show ()
                        exit(0)
                    
                    elif opcionVideo == 2:
                        print(" ")
                        print("El programa recomendado es: Adobe Premiere")
                        imagen = cargarPremiere (logo[4])
                        imagen.show ()
                        exit(0)
    
         
        

                        
                  
        
    
    
    
    

main()